import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-to-do-list-component',
  templateUrl: './to-do-list-component.component.html',
  styleUrls: ['./to-do-list-component.component.css']
})
export class ToDoListComponentComponent implements OnInit {

  @Input() addArray = [];
  
  constructor() { }

  ngOnInit(): void {
  }

  thirdArray = [];
  dummyArray = [];
  
  done(event,rowValue,i){
    if(event.target.checked){
      this.dummyArray = this.addArray.splice(i,1);
      for(let i = 0; i < this.dummyArray.length; i++){
        this.thirdArray.push(rowValue);
      }
    }
  }
  secondPushArrayMethod(evt){
    this.addArray.push(evt)
  }
}
