import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-done-list-component',
  templateUrl: './done-list-component.component.html',
  styleUrls: ['./done-list-component.component.css']
})
export class DoneListComponentComponent implements OnInit {

  @Input() thirdArray = [];
  secondArray = [];
  constructor() { }
  @Output() secondPushArray: EventEmitter<any> = new EventEmitter<any>();

  ngOnInit(): void {
  }

  dummyArray = [];

  done(event,rowValue,i){
    if(event.target.checked){
      this.dummyArray = this.thirdArray.splice(i,1);
      this.secondPushArray.emit(rowValue);
    }
  }


}
