import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-to-do-component',
  templateUrl: './create-to-do-component.component.html',
  styleUrls: ['./create-to-do-component.component.css']
})
export class CreateToDoComponentComponent implements OnInit {

  TaskName: String = "";
  TaskDescription: String = "";
  RepeatingTask: String = "";

  addArray = [];

  constructor() { }

  ngOnInit(): void {
  }

  taskValue(){
    if(this.TaskName != "" && this.TaskDescription != '' && this.RepeatingTask != ''){
      console.log(`
      TaskName : ${this.TaskName},
      TaskDescription : ${this.TaskDescription},
      RepeatingTask : ${this.RepeatingTask}
      `);
      
      var obj = {
        TaskName : this.TaskName,
        TaskDescription : this.TaskDescription,
        RepeatingTask : this.RepeatingTask,
      }

      this.addArray.push(obj);
      this.TaskName = '';
      this.TaskDescription = '';
      this.RepeatingTask = '';

    } else {
      
    }
  }

}
